# Kevin Ngicho Photography Portfolio

A showcase of Kenyan safari, nature, and lifestyle photography by **Kevin Ngicho**.

## Contact
- **Email:** ngichokevin@gmail.com
- **Instagram:** [@ja_omabei](https://instagram.com/ja_omabei)

## Hosting Instructions
1. Create a GitHub account at [github.com](https://github.com).
2. Create a new public repository named `photography-portfolio`.
3. Upload `index.html` to the root of the repository.
4. In repository **Settings → Pages**, set branch to `main` and folder to `/ (root)`.
5. After saving, your live link will appear as:

```
https://<your-username>.github.io/photography-portfolio/
```

Enjoy your new online portfolio!
